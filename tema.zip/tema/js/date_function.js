$(function() {
		    $('#dataNascimento').datetimepicker({
		      language: 'pt-BR',
		      pickTime: false
		    });
		    $('#datetimepicker2').datetimepicker({
		      language: 'pt-BR',
		      pickTime: false
		    });
});
		